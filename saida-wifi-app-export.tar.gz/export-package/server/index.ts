import express, { type Request, Response, NextFunction } from "express";
import cors from "cors";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";



const app = express();

// إعدادات CORS لحل مشاكل الطلبات من origins مختلفة
app.use(cors({
  origin: [
    'http://localhost:5000',
    'http://127.0.0.1:5000',
    'https://saidawifi.com',
    'https://www.saidawifi.com',
    /\.replit\.dev$/,
    /\.replit\.app$/
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});



(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // No need for Flutter-specific API routes - main API works fine
  
  // Serve Flutter app static files at /flutter
  app.use('/flutter', express.static('flutter_web'));
  
  // Pure HTML version (no Flutter conflicts)
  app.get('/app', (req, res) => {
    res.sendFile('pure_html.html', { root: 'flutter_web' });
  });
  
  // Hierarchical usage reports
  app.get('/hierarchical-usage', (req, res) => {
    res.sendFile('hierarchical_usage.html', { root: 'flutter_web' });
  });
  
  // Update token helper page
  app.get('/update-token', (req, res) => {
    res.sendFile('update_token.html', { root: 'flutter_web' });
  });
  
  // Flutter simple version (working HTML) 
  app.get('/flutter/simple', (req, res) => {
    res.sendFile('simple.html', { root: 'flutter_web' });
  });
  
  // Main flutter route serves the new Flutter app
  app.get('/flutter', (req, res) => {
    res.sendFile('index.html', { root: 'flutter_web' });
  });
  
  // Catch-all for Flutter app routing (but not API routes)
  app.get('/flutter/*', (req, res) => {
    // Don't serve index.html for API routes
    if (req.path.startsWith('/flutter/api/')) {
      return res.status(404).json({ error: 'API route not found' });
    }
    res.sendFile('index.html', { root: 'flutter_web' });
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    () => {
      log(`serving on port ${port}`);
    }
  );
})();
