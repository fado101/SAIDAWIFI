interface LogoProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export default function Logo({ size = "md", className = "" }: LogoProps) {
  const sizeClasses = {
    sm: "w-12 h-12 text-xs",
    md: "w-16 h-16 text-sm", 
    lg: "w-36 h-36 text-2xl"
  };

  const borderClasses = {
    sm: "border-2 border-blue-200 ring-2 ring-blue-100/40",
    md: "border-3 border-blue-200 ring-3 ring-blue-100/40",
    lg: "border-4 border-blue-200 ring-4 ring-blue-100/50"
  };

  return (
    <div className={`${sizeClasses[size]} rounded-full bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg ${borderClasses[size]} ${className} flex items-center justify-center`}>
      <span className="text-white font-bold select-none">
        SAIDA
      </span>
    </div>
  );
}